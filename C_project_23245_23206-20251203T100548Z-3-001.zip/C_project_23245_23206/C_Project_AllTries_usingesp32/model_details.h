#ifndef MODEL_DETAILS_H
#define MODEL_DETAILS_H

#define INPUT_SHAPE 3
#define NUM_CLASSES 6

const char* GESTURES[] = {"gesture_1", "gesture_2", "gesture_3", "gesture_4", "gesture_5", "gesture_6"};

#endif // MODEL_DETAILS_H
